import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    NavLink,
} from "react-router-dom";
import Home from "../home/Home";
import Contact from "../contact/Contact";
import Game from "../game/Game";

function Layout() {
    return (
        <Router>
            <NavLink to="/" exact>
                Website <br />
            </NavLink>
            <NavLink to="/" className="nav-link">
                Home
            </NavLink>
            <NavLink to="/contact" className="nav-link">
                Contact
            </NavLink>
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/contact" component={Contact} />
                <Route path="/game/:id" component={Game} />
            </Switch>
        </Router>
    );
}



export default Layout;
